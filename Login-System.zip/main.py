import time

print("This is the login system")
print()
time.sleep(1)

option = input("Do you want to make an account (A) or sign in (B)? : ")
print()
time.sleep(1)

def NewUser():
  print("Here you will create a new account!")
  print()
  time.sleep(1)
  print("-----------------------------------------")
  print()
  print("First you will create your username")
  print()
  time.sleep(1)

  def NewUserName() :
    print("Make sure your username is longer than 8 characters.")
    print()
    print("It is reccomended it has both letters and numbers.")
    print()
    time.sleep(1)
    print(" - - - - - - - - -")
    print()
    UserName = input("Enter your username: ")
    print()
    time.sleep(1)
  
    if len(UserName) < 8:
      print("That is incorrect, the username was shorter than 8 characters!")
      print()
      time.sleep(1)
      NewUserName()
      
    elif any(letter.isdigit() for letter in UserName) == False:
      print("Your username did not have any numbers.")
      print()
      time.sleep(1)
      NewUserName()
      
    else:
      print("You have a valid username!")
      print()
      print("You chose " + UserName)
      print()
      time.sleep(1)

      f = open("StoredInfo.txt", "a")
      f.write("\nUsername: " + UserName)
      f.close()
  
  NewUserName()

  print("Now you will create your password")
  print()
  time.sleep(1)
  print("Make sure your password is longer than 8 characters, has uppercase letters, lowercase letters and numbers.")
  print()
  time.sleep(1)

  def NewPassword():
    print(" - - - - - - - - -")
    print()
    Password = input("Enter your new password: ")
    print()
    time.sleep(1)

    if len(Password) < 8:
      print("Your password is too short!")
      print()
      time.sleep(1)
      NewPassword()
    elif (any(letter.islower() for letter in Password)) == False:
      print("Invalid password!")
      print("Your password does not have lowercase letters.")
      print()
      time.sleep(1)
      NewPassword()
    elif (any(letter.isupper() for letter in Password)) == False:
      print("Invalid password!")
      print("Your password does not have uppercase letters.")
      print()
      time.sleep(1)
      NewPassword()
    elif any(letter.isdigit() for letter in Password) == False:
      print("Invalid password!")
      print("Your password does not have numbers.")
      print()
      time.sleep(1)
      NewPassword()
    else:
      print("Valid password!")
      print()
      time.sleep(1)
      SeePassword = input("Do you want to see your password? (y/n) : ")
      print()
      if SeePassword == "y":
        print("Your password is " + Password)
      f = open("StoredInfo.txt", "a")
      f.write("\nPassword: " + Password)
      f.write("\n   ")
      f.close()

      time.sleep(1)
      print("-----------------------------------------")
      print()
      print("You will now be taken to the login page.")
      print()
      time.sleep(2)

  NewPassword()

def OldUser():
  print("-----------------------------------------")
  print()
  time.sleep(1)
  print("Welcome back!")
  print()
  time.sleep(1)
  print("You will enter your registered username and password...")
  print()
  time.sleep(1)

  def LoginAttempt():
    print(" - - - - - - - -")
    print()
    time.sleep(1)
    UsernameAttempt = input("What was your username? : ")
    print()
    time.sleep(1)
    PasswordAttempt = input("What was your password? : ")
    print()
    time.sleep(1)
    print(" - - - - - - - -")
    print()
    time.sleep(1)

    with open ("StoredInfo.txt") as f:
      if UsernameAttempt and PasswordAttempt in f.read():
        print("Valid username and password!")
        print()
        time.sleep(1)
        print("You are now in the system!")
        time.sleep(1)
      else:
        print("Your username or password is incorrect!")
        time.sleep(1)
        LoginAttempt()
  
  LoginAttempt()

if option.upper() == "A":
  NewUser()
elif option.upper() == "B":
  OldUser()